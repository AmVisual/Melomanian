import os

archeology = os.listdir("./archeology")
chests = os.listdir("./chests")

file = open("replace.txt","w")

for filename in archeology:
    text = filename.split(".")[0]
    file.write("\"replace_"+ text +"_archeology_loot_table\": {\n")
    file.write("\t\"type\": \"origins:replace_loot_table\",\n")
    file.write("\t\"replace\": {\n")
    file.write("\t\t\"minecraft:archeology/"+ text +"\": \"melody:archeology/"+ text +"\"\n")
    file.write("\t}\n")
    file.write("},\n")

for filename in chests:
    text = filename.split(".")[0]
    file.write("\"replace_"+ text +"_chests_loot_table\": {\n")
    file.write("\t\"type\": \"origins:replace_loot_table\",\n")
    file.write("\t\"replace\": {\n")
    file.write("\t\t\"minecraft:chests/"+ text +"\": \"melody:chests/"+ text +"\"\n")
    file.write("\t}\n")
    file.write("},\n")

file.close()